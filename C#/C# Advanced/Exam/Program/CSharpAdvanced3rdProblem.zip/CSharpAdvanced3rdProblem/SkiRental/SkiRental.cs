﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SkiRental
{
    class SkiRental
    {
        private ICollection<Ski> data;

        public SkiRental(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.data = new List<Ski>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count => this.data.Count;

        public void Add(Ski ski)
        {
            if (!EnoughSpace())
            {
                return;
            }

            this.data.Add(ski);
        }

        public bool Remove(string manufacturer, string model)
        {
            Ski ski = GetSki(manufacturer, model);

            if (ski == null)
            {
                return false;
            }

            return this.data.Remove(ski);
        }

        public Ski GetNewestSki()
        {
            return this.data.OrderByDescending(x => x.Year).FirstOrDefault();
        }

        public Ski GetSki(string manufacturer, string model)
        {
            return this.data.FirstOrDefault(x => x.Manufacturer.Equals(manufacturer) && x.Model.Equals(model));
        }

        public string GetStatistics()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"The skis stored in {this.Name}:");

            foreach (var ski in this.data)
            {
                sb.AppendLine(ski.ToString());
            }

            return sb.ToString().TrimEnd();
        }

        private bool EnoughSpace()
        {
            return this.data.Count < this.Capacity;
        }

    }
}
