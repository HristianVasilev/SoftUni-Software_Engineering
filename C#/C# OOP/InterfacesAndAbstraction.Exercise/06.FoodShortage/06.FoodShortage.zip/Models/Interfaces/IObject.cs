﻿namespace FoodShortage.Models.Interfaces
{
    interface IObject
    {
        public string Name { get; }
    }
}
