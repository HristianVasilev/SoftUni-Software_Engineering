﻿namespace _05.BirthdayCelebrations.Models.Interfaces
{
    interface IObject
    {
        public string Name { get; }
    }
}
