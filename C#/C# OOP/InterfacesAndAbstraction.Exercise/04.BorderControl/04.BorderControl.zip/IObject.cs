﻿namespace _04.BorderControl
{
    interface IObject
    {
        public string Name { get; }
        public string Id { get; }
    }
}
