﻿namespace PlayersAndMonsters.Heroes
{
    public class Knight : Hero
    {
        public Knight(string username, int level) : base(username, level)
        {
        }
    }
}
