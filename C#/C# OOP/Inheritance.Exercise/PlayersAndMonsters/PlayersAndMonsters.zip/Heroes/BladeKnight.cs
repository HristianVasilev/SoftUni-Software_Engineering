﻿namespace PlayersAndMonsters.Heroes
{
    public class BladeKnight : DarkKnight
    {
        public BladeKnight(string username, int level) : base(username, level)
        {
        }
    }
}
