﻿namespace PlayersAndMonsters.Heroes
{
    public class MuseElf : Elf
    {
        public MuseElf(string username, int level) : base(username, level)
        {
        }
    }
}
