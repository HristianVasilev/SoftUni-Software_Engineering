﻿namespace Zoo.Animals.Mammals
{
    public class Bear : Mammal
    {
        public Bear(string name) : base(name)
        {
        }
    }
}
