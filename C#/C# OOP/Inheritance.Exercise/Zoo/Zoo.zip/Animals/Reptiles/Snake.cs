﻿namespace Zoo.Animals.Reptiles
{
    public class Snake : Reptile
    {
        public Snake(string name) : base(name)
        {
        }
    }
}
