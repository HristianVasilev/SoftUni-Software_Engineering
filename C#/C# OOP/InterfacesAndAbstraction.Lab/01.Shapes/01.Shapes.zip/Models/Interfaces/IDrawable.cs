﻿namespace Shapes.Models.Interfaces
{
    public interface IDrawable
    {
        public void Draw();
    }
}
