﻿namespace _03.ShoppingSpree.Models
{
    public interface IProduct
    {
        public string Name { get; }
        public decimal Cost { get; }
    }
}