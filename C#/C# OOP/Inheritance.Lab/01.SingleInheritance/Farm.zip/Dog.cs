﻿namespace Farm
{
    internal class Dog : Animal
    {
        public void Bark()
        {
            System.Console.WriteLine("barking...");
        }
    }
}
