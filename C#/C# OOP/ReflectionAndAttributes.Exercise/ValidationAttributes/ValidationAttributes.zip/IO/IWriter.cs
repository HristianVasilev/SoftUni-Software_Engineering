﻿namespace ValidationAttributes.IO
{
    interface IWriter
    {
        void Write(object text);
    }
}
