﻿namespace ValidationAttributes.IO
{
    interface IReader
    {
        string Read();
    }
}
