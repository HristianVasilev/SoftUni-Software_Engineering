﻿namespace WarCroft.Entities.Inventory.Models
{
    class Satchel : Bag
    {
        private const int defaultCapacity = 20;

        public Satchel() : base(defaultCapacity) { }

    }
}
