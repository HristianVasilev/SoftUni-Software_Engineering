﻿namespace AVLTree
{
    using System;


    public class AVL<T> where T : IComparable<T>
    {
        private Node<T> root;

        public Node<T> Root => this.root;


        public bool Contains(T item)
        {
            return DFSSearch(this.root, item);
        }

        public void Insert(T item)
        {
            this.root = this.Insert(this.root, item);
        }


        public void EachInOrder(Action<T> action)
        {
            throw new NotImplementedException();
        }


        public void ForeachWithDFS(Node<T> node, int indent = 0)
        {
            if (node == null)
            {
                return;
            }

            ForeachWithDFS(node.Right, indent + 3);

            Console.Write(new string(' ', indent));
            Console.Write(node.Value);
            Console.WriteLine();
            ForeachWithDFS(node.Left, indent + 3);
        }


        private Node<T> Insert(Node<T> node, T value)
        {
            if (node == null)
            {
                return new Node<T>(value);
            }

            if (value.CompareTo(node.Value) < 0)
            {
                node.Left = Insert(node.Left, value);
            }
            else
            {
                node.Right = Insert(node.Right, value);
            }

            UpdateBalanceFactor(ref node);
            node = Balance(node);

            return node;
        }

        private bool DFSSearch(Node<T> node, T value)
        {
            if (node == null)
            {
                return false;
            }

            if (node.Value.Equals(value))
            {
                return true;
            }

            return DFSSearch(node.Left, value) || DFSSearch(node.Right, value);
        }

        private void DFS(Node<T> node)
        {
            if (node == null)
            {
                return;
            }

            DFS(node.Left);
            DFS(node.Left);
        }

        private Node<T> LeftLeftRotation(Node<T> node)
        {
            return LeftRotation(node);
        }

        private Node<T> LeftRightRotation(Node<T> node)
        {
            node.Left = LeftLeftRotation(node.Left);
            return RighRightRotation(node);
        }



        private Node<T> RighRightRotation(Node<T> node)
        {
            return RightRotation(node);
        }

        private Node<T> RightLeftRotation(Node<T> node)
        {
            node.Right = RighRightRotation(node.Right);
            return LeftLeftRotation(node);
        }



        private Node<T> LeftRotation(Node<T> node)
        {
            Node<T> newNode = node.Right;
            node.Right = newNode.Left;
            newNode.Left = node;

            UpdateBalanceFactor(ref node);
            UpdateBalanceFactor(ref newNode);

            return newNode;
        }

        private Node<T> RightRotation(Node<T> node)
        {
            Node<T> newNode = node.Left;
            node.Left = newNode.Right;
            newNode.Right = node;

            UpdateBalanceFactor(ref node);
            UpdateBalanceFactor(ref newNode);

            return node;
        }



        private void UpdateBalanceFactor(ref Node<T> node)
        {
            int leftHeight = 0;
            int rightHeight = 0;

            if (node.Left != null)
            {
                leftHeight = node.Left.Height;
            }
            if (node.Right != null)
            {
                rightHeight = node.Right.Height;
            }

            node.Height = 1 + Math.Max(leftHeight, rightHeight);

            node.BalanceFactor = rightHeight - leftHeight;
        }

        private Node<T> Balance(Node<T> node)
        {
            if (node.BalanceFactor == -2)
            {
                if (node.Left.BalanceFactor > 0)
                {
                    node = LeftRightRotation(node);
                }
                else
                {
                    node = RighRightRotation(node);
                }
            }
            else if (node.BalanceFactor == 2)
            {
                if (node.Right.BalanceFactor < 0)
                {
                    node = RightLeftRotation(node);
                }
                else
                {
                    node = LeftLeftRotation(node);
                }
            }

            return node;
        }
    }
}
