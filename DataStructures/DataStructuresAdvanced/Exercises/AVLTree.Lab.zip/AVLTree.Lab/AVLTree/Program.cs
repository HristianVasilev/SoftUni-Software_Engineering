﻿namespace AVLTree
{
    using System;

    class Program
    {
        static void Main(string[] args)
        {
            AVL<int> avl = new AVL<int>();

            for (int i = 1; i <= 10; i++)
            {
                avl.Insert(i);
                //avl.ForeachWithDFS(avl.Root);
                //Console.WriteLine(new string('_', 10));
            }

            for (int i = 0; i <= 10; i++)
            {
                Console.WriteLine($"Contains {i}: {avl.Contains(i)}");
            }
        }
    }
}
